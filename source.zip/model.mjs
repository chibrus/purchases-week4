export const number = value => Number(String(value).trim().replace(/\s/g, '').replace(',', '.'));
export const monthKey = date => date.slice(0, 7);
export function monthRange(end, count = 24) {
  const [year, month] = end.split('-').map(Number);
  return Array.from({length: count}, (_, i) => {
    const d = new Date(Date.UTC(year, month - count + i, 1));
    return d.toISOString().slice(0, 7);
  });
}
export function normalizeRows(input) {
  if (!Array.isArray(input) || !input.length) throw Error('В файле нет строк заказов.');
  const fields = ['order_id', 'order_date', 'item_name', 'category', 'price', 'price_discounted', 'discount', 'quantity', 'amount'];
  const missing = fields.filter(k => !(k in input[0]));
  if (missing.length) throw Error('Нет колонок: ' + missing.join(', '));
  const orders = new Map();
  return input.map((source, i) => {
    const row = {};
    for (const k of ['order_id', 'order_date', 'item_name', 'category']) {
      row[k] = String(source[k] ?? '').trim();
      if (!row[k]) throw Error(`Строка ${i + 2}: пустое поле ${k}.`);
    }
    const date = new Date(row.order_date + 'T00:00:00Z');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(row.order_date) || !Number.isFinite(+date) || date.toISOString().slice(0, 10) !== row.order_date) {
      throw Error(`Строка ${i + 2}: дата должна иметь формат YYYY-MM-DD.`);
    }
    for (const k of ['price', 'price_discounted', 'discount', 'quantity', 'amount']) {
      const raw = source[k];
      row[k] = number(raw);
      if (raw == null || String(raw).trim() === '' || !Number.isFinite(row[k]) || row[k] < 0) throw Error(`Строка ${i + 2}: некорректное значение ${k}.`);
    }
    if (row.quantity <= 0) throw Error(`Строка ${i + 2}: количество должно быть больше нуля.`);
    if (Math.abs(row.amount - row.price_discounted * row.quantity) > .011 || Math.abs(row.discount - (row.price - row.price_discounted)) > .011) {
      throw Error(`Строка ${i + 2}: сумма, цена или скидка не согласованы. Данные не загружены.`);
    }
    row.status = String(source.status ?? '').trim();
    const signature = row.order_date + '|' + row.status;
    if (orders.has(row.order_id) && orders.get(row.order_id) !== signature) throw Error(`У заказа ${row.order_id} разные даты или статусы.`);
    orders.set(row.order_id, signature);
    row.month = monthKey(row.order_date);
    row.productKey = JSON.stringify([row.category, row.item_name]);
    return row;
  });
}
export function summarize(rows) {
  const count = rows.length;
  return {
    orders: new Set(rows.map(r => r.order_id)).size,
    spend: rows.reduce((s, r) => s + r.amount, 0),
    units: rows.reduce((s, r) => s + r.quantity, 0),
    discount: count ? rows.reduce((s, r) => s + r.discount, 0) / count : null,
    lines: count,
  };
}
export function monthly(rows, months) {
  return months.map(month => ({month, ...summarize(rows.filter(r => r.month === month))}));
}
export function products(rows, months) {
  const groups = new Map();
  for (const r of rows) {
    if (!groups.has(r.productKey)) groups.set(r.productKey, []);
    groups.get(r.productKey).push(r);
  }
  return [...groups].map(([key, group]) => ({
    key, name: group[0].item_name, category: group[0].category, ...summarize(group),
    unitPrice: group.reduce((s, r) => s + r.amount, 0) / group.reduce((s, r) => s + r.quantity, 0),
    history: months.map(month => {
      const subset = group.filter(r => r.month === month);
      return {month, price: subset.length ? subset.reduce((s, r) => s + r.amount, 0) / subset.reduce((s, r) => s + r.quantity, 0) : null};
    }),
  }));
}
export function categories(rows) {
  return [...new Set(rows.map(r => r.category))].map(name => ({name, ...summarize(rows.filter(r => r.category === name))})).sort((a, b) => b.spend - a.spend || a.name.localeCompare(b.name, 'ru'));
}
