import {normalizeRows, summarize, monthly, products, categories, monthRange} from './model.mjs';
const {createApp, ref, computed, watch, nextTick, onMounted, onBeforeUnmount} = Vue;
const fmt = n => n == null ? 'Нет данных' : new Intl.NumberFormat('ru-RU', {maximumFractionDigits: 1}).format(n);
const money = n => n == null ? 'Нет данных' : new Intl.NumberFormat('ru-RU', {maximumFractionDigits: 0}).format(n);
const pct = n => fmt(Number.isFinite(n) ? n : 0);
const monthLabel = m => new Date(m + '-01T00:00:00Z').toLocaleDateString('ru-RU', {month:'short',year:'numeric',timeZone:'UTC'});
const fullDate = d => d ? new Date(d + 'T00:00:00Z').toLocaleDateString('ru-RU', {timeZone:'UTC'}) : '';
const palette = ['#514bc6','#237f86','#cf623c','#bc5490','#5276bc','#77953d','#a67a34','#925bc3','#379a91','#bc7053','#657084'];
const imageKey = name => name.normalize('NFC').toLocaleLowerCase('ru').replaceAll('\u0451','е').replace(/[^\p{L}\p{N}]/gu,'');
const searchText = value => value.normalize('NFC').toLocaleLowerCase('ru').replaceAll('\u0451','е').trim().replace(/\s+/g,' ');
const categoryIcons={'Готовая еда':'prepared','Сладости':'sweets','Снеки':'snacks','Напитки':'drinks','Фрукты':'fruit','Вода':'water','База':'basic','Овощи':'vegetable','Товары для дома':'home','Аптека':'pharmacy','Услуги Груши':'service'};
const imagePath=(name,category,images)=>images[imageKey(name)]||(categoryIcons[category]?'assets/categories/'+categoryIcons[category]+'.svg':null);
function observeChart(element, draw) {
  const observer = new ResizeObserver(draw);
  observer.observe(element);
  draw();
  return () => observer.disconnect();
}
function clipText(selection, maxWidth) {
  selection.each(function(){
    const full=this.textContent;
    if(this.getComputedTextLength()<=maxWidth)return;
    let left=0,right=full.length;
    while(left<right){
      const middle=Math.ceil((left+right)/2);
      this.textContent=full.slice(0,middle)+'...';
      if(this.getComputedTextLength()<=maxWidth)left=middle;else right=middle-1;
    }
    this.textContent=full.slice(0,left)+'...';
  });
}
const TrendChart = {
  props: ['data','field','color','label','format'],
  template: '<div class="spark" ref="host"><svg ref="svg" role="img" :aria-label="label+\': 24 месяца\'"></svg><div v-if="tip" class="spark-tip">{{tip}}</div></div>',
  setup(props) {
    const host=ref(null), svg=ref(null), tip=ref(''); let dispose;
    const draw=()=>{
      if(!svg.value) return;
      const w=host.value.clientWidth, h=82, root=d3.select(svg.value).attr('viewBox',`0 0 ${w} ${h}`); root.selectAll('*').remove();
      const x=d3.scaleBand().domain(props.data.map(d=>d.month)).range([0,w]).padding(.3);
      const y=d3.scaleLinear().domain([0,d3.max(props.data,d=>d[props.field])||1]).range([h-3,4]);
      root.append('line').attr('x1',0).attr('x2',w).attr('y1',h-2).attr('y2',h-2).attr('stroke','#e1e6ef');
      const bars=root.selectAll('g').data(props.data).join('g').attr('tabindex',0).attr('role','img').attr('aria-label',d=>`${monthLabel(d.month)}: ${props.format(d[props.field])}`);
      bars.append('rect').attr('x',d=>x(d.month)).attr('y',d=>y(d[props.field]||0)).attr('width',x.bandwidth()).attr('height',d=>Math.max(d[props.field]>0?1:0,h-3-y(d[props.field]||0))).attr('rx',2).attr('fill',props.color).attr('opacity',(_,i)=>i===props.data.length-1?1:.35);
      bars.append('rect').attr('x',d=>x(d.month)-2).attr('y',0).attr('width',x.bandwidth()+4).attr('height',h).attr('fill','transparent');
      bars.on('pointerenter focus',(_,d)=>{tip.value=`${monthLabel(d.month)}: ${props.format(d[props.field])}`;}).on('pointerleave blur',()=>{tip.value='';});
    };
    onMounted(()=>{dispose=observeChart(host.value,draw);}); onBeforeUnmount(()=>dispose?.()); watch(()=>[props.data,props.field],draw,{deep:true});
    return {host,svg,tip};
  }
};
function drawPrice(element, data, compact=false) {
  const svg=d3.select(element); svg.selectAll('*').remove();
  const w=element.parentElement.clientWidth || 280, h=compact?80:170;
  const margin={top:12,right:12,bottom:compact?18:30,left:compact?8:47};
  svg.attr('viewBox',`0 0 ${w} ${h}`);
  const valid=data.filter(d=>d.price!==null), x=d3.scalePoint().domain(data.map(d=>d.month)).range([margin.left,w-margin.right]);
  const y=d3.scaleLinear().domain([0,d3.max(valid,d=>d.price)||1]).nice().range([h-margin.bottom,margin.top]);
  if(!valid.length){svg.append('text').attr('x',12).attr('y',35).attr('fill','#657084').text('Покупок за период нет');return;}
  if(!compact){
    svg.append('g').attr('transform',`translate(${margin.left},0)`).call(d3.axisLeft(y).ticks(4).tickSize(-(w-margin.left-margin.right)).tickFormat(d=>money(d))).call(g=>g.select('.domain').remove()).call(g=>g.selectAll('line').attr('stroke','#e7eaf2')).call(g=>g.selectAll('text').attr('fill','#657084'));
  }
  const ticks=[data[0].month,data[Math.floor(data.length/2)].month,data.at(-1).month];
  svg.append('g').attr('transform',`translate(0,${h-margin.bottom})`).call(d3.axisBottom(x).tickValues([...new Set(ticks)]).tickSize(0).tickFormat(monthLabel)).call(g=>g.select('.domain').remove()).call(g=>g.selectAll('text').attr('fill','#657084').attr('font-size',compact?8:10).attr('dy',14));
  svg.append('path').datum(data).attr('fill','none').attr('stroke','#514bc6').attr('stroke-width',2).attr('d',d3.line().defined(d=>d.price!==null).x(d=>x(d.month)).y(d=>y(d.price)));
  svg.selectAll('circle').data(valid).join('circle').attr('cx',d=>x(d.month)).attr('cy',d=>y(d.price)).attr('r',compact?2.5:4).attr('fill','#514bc6').append('title').text(d=>`${monthLabel(d.month)}: ${money(d.price)} руб./шт.`);
}
const PriceChart={props:['data'],template:'<div class="price-chart" ref="host"><svg ref="svg" role="img" aria-label="Средняя цена покупки по месяцам"></svg></div>',setup(props){const host=ref(null),svg=ref(null);let dispose;const draw=()=>svg.value&&drawPrice(svg.value,props.data);onMounted(()=>{dispose=observeChart(host.value,draw);});onBeforeUnmount(()=>dispose?.());watch(()=>props.data,draw,{deep:true});return{host,svg};}};
const ProductChart={
  props:['products','images','color'],emits:['inspect'],
  template:'<div class="product-chart" ref="host"><svg ref="svg" role="group" aria-label="Рейтинг товаров: количество и траты"></svg></div>',
  setup(props,{emit}) {
    const host=ref(null), svg=ref(null); let dispose, tooltip;
    const hide=()=>{tooltip?.remove();tooltip=null;};
    const show=(event,item)=>{
      hide(); const el=document.createElement('div');el.className='chart-tooltip';el.setAttribute('role','tooltip');
      const img=imagePath(item.name,item.category,props.images);
      if(img){const image=document.createElement('img');image.src=img;image.alt='';image.className='tooltip-img';el.append(image);}
      const title=document.createElement('h3');title.textContent=item.name;el.append(title);
      const category=document.createElement('p');category.textContent=item.category;el.append(category);
      if(img&&!props.images[imageKey(item.name)]){const credit=document.createElement('p');credit.textContent='Иллюстрация категории';el.append(credit);}
      const values=document.createElement('div');values.className='tooltip-values';
      for(const [value,label] of [[fmt(item.units),'штук'],[money(item.spend),'руб.'],[fmt(item.orders),'заказов']]){const block=document.createElement('div');const strong=document.createElement('strong');strong.textContent=value;const small=document.createElement('span');small.textContent=label;block.append(strong,small);values.append(block);}
      el.append(values);const note=document.createElement('p');note.textContent='Средняя цена покупки по месяцам, руб./шт.';el.append(note);
      const chart=document.createElement('div');chart.className='tooltip-chart';const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');chart.append(svg);el.append(chart);
      const range=item.history.filter(d=>d.price!==null);
      const facts=document.createElement('p');facts.textContent=range.length?`${monthLabel(range[0].month)}: ${money(range[0].price)} руб. / ${monthLabel(range.at(-1).month)}: ${money(range.at(-1).price)} руб.`:'Покупок нет';el.append(facts);
      const hint=document.createElement('p');hint.textContent='Нажмите для всех месячных значений';el.append(hint);
      document.body.append(el);drawPrice(svg,item.history,true);
      const rect=event.currentTarget.getBoundingClientRect();
      const left=Math.min(window.innerWidth-el.offsetWidth-12,Math.max(12,(event.clientX||rect.x)+16));
      const top=Math.min(window.innerHeight-el.offsetHeight-12,Math.max(12,(event.clientY||rect.y)-80));
      el.style.left=left+'px';el.style.top=top+'px';tooltip=el;
    };
    const draw=()=>{
      hide();if(!svg.value)return;
      const width=host.value.clientWidth-24, rowHeight=55, h=props.products.length*rowHeight+45;
      const compact=width<520, nameWidth=Math.min(compact?152:340,width*.43), gap=compact?13:25, plotWidth=(width-nameWidth-gap-15)/2;
      const xUnits=d3.scaleLinear().domain([0,d3.max(props.products,d=>d.units)||1]).range([0,plotWidth]);
      const xSpend=d3.scaleLinear().domain([0,d3.max(props.products,d=>d.spend)||1]).range([0,plotWidth]);
      const root=d3.select(svg.value).attr('viewBox',`0 0 ${width} ${h}`).attr('height',h);root.selectAll('*').remove();
      const header=root.append('g').attr('fill','#657084').attr('font-size',10);
      header.append('text').attr('x',8).attr('y',20).text('ТОВАР');
      header.append('text').attr('x',nameWidth).attr('y',20).text('ШТУКИ');
      header.append('text').attr('x',nameWidth+plotWidth+gap).attr('y',20).text('ТРАТЫ, РУБ.');
      const groups=root.selectAll('.product-row').data(props.products,d=>d.key).join('g').attr('class','product-row').attr('data-product-key',d=>d.key).attr('transform',(_,i)=>`translate(0,${34+i*rowHeight})`).attr('tabindex',0).attr('role','button').attr('aria-label',d=>`${d.name}, ${fmt(d.units)} штук, ${money(d.spend)} рублей. Открыть историю цены.`);
      groups.append('rect').attr('class','row-bg').attr('width',width).attr('height',rowHeight).attr('rx',5).attr('fill','white');
      groups.append('line').attr('x1',8).attr('x2',width-4).attr('y1',rowHeight-1).attr('y2',rowHeight-1).attr('stroke','#eff1f6');
      groups.append('rect').attr('x',6).attr('y',8).attr('width',35).attr('height',35).attr('rx',6).attr('fill',d=>props.color(d.category)).attr('opacity',.12);
      groups.each(function(d){const group=d3.select(this),src=imagePath(d.name,d.category,props.images);if(src){group.append('image').attr('href',src).attr('x',7).attr('y',8).attr('width',33).attr('height',35).attr('preserveAspectRatio','xMidYMid meet');}else{group.append('text').attr('x',23).attr('y',31).attr('text-anchor','middle').attr('font-size',15).attr('fill',props.color(d.category)).text(d.name.slice(0,1));}});
      groups.append('text').attr('x',50).attr('y',23).attr('fill','#182238').attr('font-size',compact?10:12).text(d=>d.name);
      groups.append('text').attr('x',50).attr('y',39).attr('fill','#657084').attr('font-size',9).text(d=>d.category);
      clipText(groups.selectAll('text[x="50"]'),Math.max(10,nameWidth-58));
      for (const [field,x,start,color] of [['units',xUnits,nameWidth,'#a5b7d3'],['spend',xSpend,nameWidth+plotWidth+gap,'#514bc6']]){
        groups.append('rect').attr('x',start).attr('y',32).attr('width',plotWidth).attr('height',5).attr('fill','#f0f2f7').attr('rx',2);
        groups.append('rect').attr('x',start).attr('y',32).attr('width',d=>x(d[field])).attr('height',5).attr('fill',color).attr('rx',2);
        groups.append('text').attr('x',start).attr('y',24).attr('font-size',compact?11:13).attr('font-weight',600).attr('fill','#182238').text(d=>field==='spend'?money(d[field]):fmt(d[field]));
      }
      groups.on('pointerenter focus',show).on('pointerleave blur',hide).on('click',(event,d)=>{hide();emit('inspect',d,event.currentTarget);}).on('keydown',(event,d)=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();hide();emit('inspect',d,event.currentTarget);}if(event.key==='Escape')hide();});
    };
    onMounted(()=>{dispose=observeChart(host.value,draw);window.addEventListener('scroll',hide,true);});onBeforeUnmount(()=>{dispose?.();hide();window.removeEventListener('scroll',hide,true);});watch(()=>[props.products,props.images],draw,{deep:true});return{host,svg};
  }
};
createApp({
  components:{TrendChart,ProductChart,PriceChart},
  setup(){
    const rows=ref([]), images=ref({}), error=ref(''),loading=ref(true),sourceName=ref('Датасет первой недели, вариант C');
    const period=ref('24'),status=ref('доставлен'),category=ref('all'),sort=ref('spend'),search=ref(''),limit=ref(12),selected=ref(null),detail=ref(null);let openerKey=null;
    const statuses=computed(()=>[...new Set(rows.value.map(r=>r.status))].filter(Boolean).sort());
    const allCategories=computed(()=>[...new Set(rows.value.map(r=>r.category))].sort((a,b)=>a.localeCompare(b,'ru')));
    const categoryColor=name=>palette[Math.max(0,allCategories.value.indexOf(name))%palette.length];
    const firstDate=computed(()=>rows.value.length?rows.value.reduce((a,r)=>r.order_date<a?r.order_date:a,rows.value[0].order_date):'');
    const lastDate=computed(()=>rows.value.length?rows.value.reduce((a,r)=>r.order_date>a?r.order_date:a,rows.value[0].order_date):'');
    const endMonth=computed(()=>lastDate.value.slice(0,7));
    const trendMonths=computed(()=>endMonth.value?monthRange(endMonth.value):[]);
    const periodMonths=computed(()=>!endMonth.value?[]:period.value==='all'?monthRange(endMonth.value,(+endMonth.value.slice(0,4)-+firstDate.value.slice(0,4))*12+(+endMonth.value.slice(5,7)-+firstDate.value.slice(5,7))+1):monthRange(endMonth.value,Number(period.value)));
    const baseRows=computed(()=>rows.value.filter(r=>status.value==='all'||r.status===status.value));
    const chosenRows=computed(()=>baseRows.value.filter(r=>category.value==='all'||r.category===category.value));
    const trends=computed(()=>monthly(chosenRows.value,trendMonths.value));
    const current=computed(()=>trends.value.at(-1)||summarize([]));
    const rangeLabel=computed(()=>periodMonths.value.length?monthLabel(periodMonths.value[0])+' - '+monthLabel(endMonth.value):'');
    const categoryRows=computed(()=>baseRows.value.filter(r=>periodMonths.value.includes(r.month)));
    const categoryStats=computed(()=>categories(categoryRows.value));
    const categoryTotals=computed(()=>summarize(categoryRows.value));
    const productStats=computed(()=>products(chosenRows.value.filter(r=>periodMonths.value.includes(r.month)),periodMonths.value));
    const filteredProducts=computed(()=>productStats.value.filter(p=>searchText(p.name).includes(searchText(search.value))).sort((a,b)=>b[sort.value]-a[sort.value]||a.name.localeCompare(b.name,'ru')));
    const visibleProducts=computed(()=>filteredProducts.value.slice(0,limit.value));
    const metrics=[{key:'orders',title:'Количество заказов',unit:'заказов',color:'#514bc6',format:fmt},{key:'spend',title:'Сумма трат',unit:'руб.',color:'#237f86',format:money},{key:'discount',title:'Средняя скидка',unit:'руб. / строку',color:'#cf623c',format:fmt}];
    function comparison(metric){const a=current.value[metric.key],b=trends.value.at(-2)?.[metric.key];if(a==null||b==null)return'Нет данных для сравнения с прошлым месяцем';if(b===0)return a===0?'Без изменений к прошлому месяцу':'В прошлом месяце значение равно нулю';const change=(a-b)/b*100;return(change>0?'+':'')+fmt(change)+'% к прошлому месяцу';}
    function reset(){period.value='24';status.value=statuses.value.includes('доставлен')?'доставлен':'all';category.value='all';search.value='';sort.value='spend';}
    watch([period,status,category,sort,search],()=>{limit.value=12;selected.value=null;});
    watch(selected,async value=>{document.body.style.overflow=value?'hidden':'';await nextTick();if(value)detail.value?.focus();else requestAnimationFrame(()=>requestAnimationFrame(()=>{if(!selected.value)[...document.querySelectorAll('.product-row')].find(row=>row.getAttribute('data-product-key')===openerKey)?.focus();}));});
    function inspect(product){openerKey=product.key;selected.value=product;}
    function trapFocus(event){const elements=[...detail.value.querySelectorAll('button,[href],input,[tabindex="0"]')];const first=elements[0],last=elements.at(-1);if(event.shiftKey&&(document.activeElement===first||document.activeElement===detail.value)){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}
    function applyRows(input,name){const next=normalizeRows(input);rows.value=next;sourceName.value=name;reset();error.value='';}
    async function importFile(event){const file=event.target.files[0];if(!file)return;try{const text=await file.text();const input=file.name.toLowerCase().endsWith('.json')?JSON.parse(text):d3.dsvFormat(text.split('\n')[0].includes(';')?';':',').parse(text.replace(/^\uFEFF/,''));applyRows(input.rows||input,file.name);}catch(e){error.value=e.message;}finally{event.target.value='';}}
    onMounted(async()=>{try{const response=await fetch('data/orders.json');if(!response.ok)throw Error('Файл данных не найден. Загрузите CSV через кнопку сверху.');const payload=await response.json();applyRows(payload.rows||payload,payload.source||sourceName.value);try{const imageResponse=await fetch('data/images.json');if(imageResponse.ok)images.value=await imageResponse.json();}catch{} }catch(e){error.value=e.message;}finally{loading.value=false;}});
    return{rows,images,error,loading,sourceName,period,status,category,sort,search,limit,selected,detail,statuses,allCategories,categoryColor,firstDate,lastDate,endMonth,trendMonths,trends,current,rangeLabel,categoryStats,categoryTotals,filteredProducts,visibleProducts,metrics,comparison,reset,inspect,trapFocus,importFile,fmt,money,pct,monthLabel,fullDate,imageFor:(name,category)=>imagePath(name,category,images.value)};
  }
}).mount('#app');
