"""Bundle the tested static dashboard into one portable HTML file."""
import base64
import json
import mimetypes
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / 'publish'


def script_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def main():
    payload = json.loads((ROOT / 'data/orders.json').read_text('utf-8'))
    assert all(set(row) == {'order_date', 'status', 'item_name', 'category', 'price', 'price_discounted', 'discount', 'quantity', 'amount', 'order_id'} for row in payload['rows'])
    images = json.loads((ROOT / 'data/images.json').read_text('utf-8'))
    embedded_images = {}
    for name, relative in images.items():
        path = (ROOT / relative).resolve()
        assert path.is_relative_to(ROOT.resolve())
        mime = mimetypes.guess_type(path)[0]
        assert mime and mime.startswith('image/')
        embedded_images[name] = 'data:' + mime + ';base64,' + base64.b64encode(path.read_bytes()).decode('ascii')
    model = re.sub(r'^export ', '', (ROOT / 'model.mjs').read_text('utf-8'), flags=re.MULTILINE)
    app = (ROOT / 'app.mjs').read_text('utf-8')
    app, imports = re.subn(r'^import .*? from \'\./model\.mjs\';\n', '', app, count=1)
    assert imports == 1
    old_mount = next(line for line in app.splitlines() if line.startswith('    onMounted(async()=>{try{const response=await fetch('))
    new_mount = "    onMounted(()=>{try{applyRows(embeddedOrders.rows,embeddedOrders.source||sourceName.value);images.value=embeddedImages;}catch(e){error.value=e.message;}finally{loading.value=false;}});"
    app = app.replace(old_mount, new_mount)
    assert 'fetch(' not in app
    inline = 'const embeddedOrders=' + script_json(payload) + ';\nconst embeddedImages=' + script_json(embedded_images) + ';\n' + model + '\n' + app
    html = (ROOT / 'index.html').read_text('utf-8')
    for name in ['vue.global.prod.js', 'd3.min.js']:
        code = (ROOT / 'vendor' / name).read_text('utf-8').replace('</script', '<\\/script')
        html = html.replace(f'<script defer src="vendor/{name}"></script>', '<script>' + code + '</script>')
    html = html.replace('<script type="module" src="app.mjs"></script>', '<script type="module">' + inline.replace('</script', '<\\/script') + '</script>')
    html = html.replace('<link rel="stylesheet" href="style.css">', '<style>' + (ROOT / 'style.css').read_text('utf-8') + '</style>')
    # Preserve category fallbacks for optional CSV imports without external assets.
    icons = {p.stem: 'data:image/svg+xml;base64,' + base64.b64encode(p.read_bytes()).decode('ascii') for p in (ROOT / 'assets/categories').glob('*.svg')}
    html = html.replace("'assets/categories/'+categoryIcons[category]+'.svg'", 'embeddedCategoryIcons[categoryIcons[category]]')
    html = html.replace('const embeddedOrders=', 'const embeddedCategoryIcons=' + script_json(icons) + ';\nconst embeddedOrders=', 1)
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT / 'index.html').write_text(html, encoding='utf-8')
    (OUTPUT / '.nojekyll').write_text('', encoding='utf-8')
    (OUTPUT / 'README.md').write_text('''# Мои покупки, неделя 4

Интерактивный дашборд на Vue 3.5.13 и D3 7.9.0.

Публичный сайт: https://chibrus.github.io/purchases-week4/

index.html содержит все стили, код, данные и 338 изображений. Внешних CDN и серверного API нет. Исходный проект с отдельными файлами, подготовкой данных, лицензиями и тестами находится в source.zip.

Показаны заказы, траты и средняя скидка за последний месяц, динамика за 24 месяца, рейтинг товаров в штуках и рублях, категории и история цены покупки. Есть фильтры, сортировка, поиск и подсказки.

Методика: COUNTD(order_id), SUM(amount), SUM(quantity), AVG(discount) в рублях на товарную строку. Цена покупки по месяцу = SUM(amount) / SUM(quantity). Последний месяц данных может быть неполным. Заказы по категориям не складываются.

Учебный датасет первой недели, вариант C. Адреса и время доставки исключены, исходные ID заказов заменены техническими номерами. Для 72 изображений принято предположение о соответствии учебного бренда Груша бренду Лавка в positions.csv; остальное название и категория совпадают. Полная история сопоставлений сохранена в исходном проекте.

Автор работы: Руслан Чибиров. Vue: MIT. D3: ISC. Лицензии сохранены в source.zip.
''', encoding='utf-8')
    with zipfile.ZipFile(OUTPUT / 'source.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts or '.git' in path.parts:
                continue
            relative = path.relative_to(ROOT)
            if relative.parts[0] == 'tests' and path.suffix.lower() == '.png':
                continue
            archive.write(path, relative.as_posix())
    print(json.dumps({'output': str(OUTPUT), 'html_bytes': (OUTPUT / 'index.html').stat().st_size, 'images': len(embedded_images)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
