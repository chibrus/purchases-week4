"""Prepare a public, minimized dataset. Run from the dashboard directory."""
import argparse
import csv
import hashlib
import io
import json
import unicodedata
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath
from PIL import Image

ROOT = Path(__file__).resolve().parent
KEEP = ['order_date', 'status', 'item_name', 'category', 'price', 'price_discounted', 'discount', 'quantity', 'amount']


def key(name):
    return ''.join(c for c in normalize(name) if c.isalnum())


def normalize(value):
    return unicodedata.normalize('NFC', value).strip().casefold().replace('\u0451', '\u0435')


def course_brand_alias(value):
    # Only the course brand is replaced. Fruit flavor words remain unchanged.
    return normalize(value).replace('из груши', 'из лавки').replace(' x груша', ' x лавка').replace('услуги груши', 'услуги лавки')


def zip_name(info):
    name = info.filename
    if not info.flag_bits & 0x800:
        try:
            name = name.encode('cp437').decode('utf-8')
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    return unicodedata.normalize('NFC', name.replace('\\', '/'))


def prepare_images(source, rows, allow_brand_alias=False):
    """Read only CSV and raster images. Never extract archive paths to disk."""
    if source.is_file():
        with zipfile.ZipFile(source) as archive:
            members = {}
            for info in archive.infolist():
                name = zip_name(info)
                if info.is_dir() or '__MACOSX' in PurePosixPath(name).parts:
                    continue
                if name in members:
                    raise ValueError('Duplicate normalized archive path: ' + name)
                members[name] = info
            tables = [name for name in members if PurePosixPath(name).name == 'positions.csv']
            if len(tables) != 1:
                raise ValueError('Expected exactly one positions.csv in the archive')
            table_path = tables[0]
            table_bytes = archive.read(members[table_path])
            base = PurePosixPath(table_path).parent

            def read_image(filename):
                path = unicodedata.normalize('NFC', str(base / filename))
                return archive.read(members[path])

            return map_images(table_bytes, read_image, rows, allow_brand_alias)
    tables = list(source.rglob('positions.csv'))
    if len(tables) != 1:
        raise ValueError('Expected exactly one positions.csv in the image directory')
    table = tables[0]

    def read_image(filename):
        target = (table.parent / filename).resolve()
        if not target.is_relative_to(table.parent.resolve()):
            raise ValueError('Image path leaves the positions.csv directory')
        return target.read_bytes()

    return map_images(table.read_bytes(), read_image, rows, allow_brand_alias)


def map_images(table_bytes, read_image, rows, allow_brand_alias):
    mappings = list(csv.DictReader(io.StringIO(table_bytes.decode('utf-8-sig')), delimiter=';'))
    required = {'Код', 'Название позиции', 'Категория', 'Файл'}
    if not mappings or not required.issubset(mappings[0]):
        raise ValueError('Invalid positions.csv columns')
    by_product = {}
    for mapping in mappings:
        product = (normalize(mapping['Категория']), normalize(mapping['Название позиции']))
        if product in by_product:
            raise ValueError('Ambiguous positions.csv product: ' + mapping['Название позиции'])
        by_product[product] = mapping
    manifest, audit, pending_files = {}, [], {}
    for category, name in sorted({(r['category'], r['item_name']) for r in rows}):
        product = (normalize(category), normalize(name))
        mapping = by_product.get(product)
        match_type = 'exact'
        if mapping is None and allow_brand_alias:
            mapping = by_product.get((course_brand_alias(category), course_brand_alias(name)))
            match_type = 'course_brand_alias'
        if mapping is None:
            audit.append({'category': category, 'item_name': name, 'match': 'missing'})
            continue
        suffix = PurePosixPath(mapping['Файл']).suffix.lower()
        if suffix not in {'.png', '.jpg', '.jpeg', '.webp', '.avif'}:
            raise ValueError('Unsupported image format: ' + suffix)
        content = read_image(mapping['Файл'])
        with Image.open(io.BytesIO(content)) as image:
            image.verify()
        target = 'items/' + hashlib.sha256((category + '\0' + name).encode()).hexdigest()[:20] + suffix
        image_key = key(name)
        if image_key in manifest and manifest[image_key] != target:
            raise ValueError('Ambiguous dashboard image key: ' + name)
        manifest[image_key] = target
        pending_files[target] = content
        audit.append({'category': category, 'item_name': name, 'match': match_type,
                      'position_code': mapping['Код'], 'mapped_name': mapping['Название позиции'],
                      'mapped_category': mapping['Категория'], 'source_file': mapping['Файл'],
                      'image': target, 'sha256': hashlib.sha256(content).hexdigest()})
    # Validation completes before any images or manifests are changed.
    for target, content in pending_files.items():
        (ROOT / target).parent.mkdir(exist_ok=True)
        (ROOT / target).write_bytes(content)
    return manifest, audit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--images', type=Path)
    parser.add_argument('--allow-course-brand-alias', action='store_true', help='Map only the course brand Grusha to Lavka, keeping product descriptors and category identical')
    args = parser.parse_args()
    with args.input.open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    required = set(KEEP + ['order_id'])
    if not rows or required - rows[0].keys():
        raise ValueError('Missing required columns or empty input')
    ids = {}
    output = []
    for row in rows:
        ids.setdefault(row['order_id'], str(len(ids) + 1))
        item = {k: row[k] for k in KEEP}
        item['order_id'] = ids[row['order_id']]
        for field in ['price', 'price_discounted', 'discount', 'quantity', 'amount']:
            item[field] = float(item[field])
        output.append(item)
    manifest = {}
    image_audit = None
    if args.images:
        manifest, image_audit = prepare_images(args.images, rows, args.allow_course_brand_alias)
    elif (ROOT / 'data/images.json').exists():
        manifest = json.loads((ROOT / 'data/images.json').read_text(encoding='utf-8'))
    data = ROOT / 'data'
    data.mkdir(exist_ok=True)
    # The public file contains no address, delivery times or source order IDs.
    (data / 'orders.json').write_text(json.dumps({'source': args.input.name, 'rows': output}, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    (data / 'images.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    if image_audit is not None:
        (data / 'image-mapping.json').write_text(json.dumps(image_audit, ensure_ascii=False, indent=2), encoding='utf-8')
    delivered = [r for r in output if r['status'] == 'доставлен']
    report = {'rows': len(rows), 'orders': len(ids), 'date_min': min(r['order_date'] for r in output), 'date_max': max(r['order_date'] for r in output), 'statuses': dict(Counter(r['status'] for r in output)), 'delivered_amount': sum(r['amount'] for r in delivered), 'images_matched': len(manifest)}
    if image_audit is not None:
        report['image_matches'] = dict(Counter(r['match'] for r in image_audit))
        report['image_alias_assumption'] = 'Учебный бренд Груша соответствует Лавке в positions.csv. Заменяется только обозначение бренда, остальные слова и категория должны совпадать.' if args.allow_course_brand_alias else None
    (data / 'quality-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
