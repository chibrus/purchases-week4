@echo off
cd /d "%~dp0"
set "task_python=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%task_python%" (
  "%task_python%" serve.py
) else (
  py serve.py
)
pause
