"""Local preview: python serve.py. No installation or external services needed."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser

if __name__ == '__main__':
    handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent))
    for port in range(4173, 4184):
        try:
            server = ThreadingHTTPServer(('127.0.0.1', port), handler)
            break
        except OSError:
            continue
    else:
        raise SystemExit('No free preview port in 4173..4183')
    print(f'http://127.0.0.1:{port}/  Stop: Ctrl+C', flush=True)
    webbrowser.open(f'http://127.0.0.1:{port}/')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
