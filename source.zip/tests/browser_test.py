"""Run against the local server. Optional --base-url for a public URL."""
import argparse
import csv
import json
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--base-url', default='http://127.0.0.1:4173/')
args = parser.parse_args()

with (ROOT.parent / 'Неделя 1_Визуализация_Датасет_Вариант C.csv').open(encoding='utf-8-sig', newline='') as stream:
    original = list(csv.DictReader(stream))
latest = max(r['order_date'] for r in original)[:7]
last_month = [r for r in original if r['order_date'].startswith(latest) and r['status'] == 'доставлен']
expected = [len({r['order_id'] for r in last_month}), sum(float(r['amount']) for r in last_month), sum(float(r['discount']) for r in last_month) / len(last_month)]

def numeric(text):
    return float(text.replace('\xa0', '').replace('\u202f', '').replace(' ', '').replace(',', '.'))

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, channel='msedge')
    # A new context has no login state, cache, local storage or cookies.
    context = browser.new_context(viewport={'width': 1536, 'height': 1100}, device_scale_factor=1)
    page = context.new_page()
    errors, bad_responses = [], []
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.on('response', lambda res: bad_responses.append(res.url) if res.status >= 400 else None)
    response = page.goto(args.base_url, wait_until='networkidle')
    assert response.status == 200
    expect(page.locator('.metric-value')).to_have_count(3)
    observed = [numeric(s) for s in page.locator('.metric-value').all_text_contents()]
    assert observed[:2] == expected[:2], (observed, expected)
    assert abs(observed[2] - expected[2]) <= .051
    assert page.locator('.spark svg > g').count() == 72
    assert page.locator('.product-row').count() == 12
    assert page.locator('.product-row image').count() == 12
    assert page.locator('.product-row image').evaluate_all(r'(els)=>els.every(e=>/^(items\/|data:image\/)/.test(e.getAttribute("href")))')
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
    page.screenshot(path=str(ROOT / 'tests/desktop-preview.png'), full_page=True)
    # Hover tooltip includes real price history and factual values.
    page.locator('.product-row').nth(1).hover()
    expect(page.locator('.chart-tooltip')).to_be_visible()
    assert page.locator('.chart-tooltip img').get_attribute('src').startswith(('items/', 'data:image/'))
    page.wait_for_function('document.querySelector(".chart-tooltip img")?.naturalWidth > 0')
    assert page.locator('.chart-tooltip svg circle').count() > 0
    page.locator('.product-row').nth(1).click()
    expect(page.get_by_role('dialog')).to_be_visible()
    assert page.locator('.detail-intro img').get_attribute('src').startswith(('items/', 'data:image/'))
    page.wait_for_function('document.querySelector(".detail-intro img")?.naturalWidth > 0')
    assert page.locator('.price-values span').count() > 0
    page.screenshot(path=str(ROOT / 'tests/tooltip-preview.png'))
    page.keyboard.press('Escape')
    expect(page.get_by_role('dialog')).to_have_count(0)
    # Sorting units must place a maximum quantity first.
    page.get_by_role('button', name='По количеству', exact=True).click()
    labels = page.locator('.product-row').evaluate_all('(els)=>els.map(e=>e.getAttribute("aria-label"))')
    assert labels[0].startswith('Доставка, 178 штук'), labels[0]
    page.get_by_role('button', name='Показать еще 20').click()
    expect(page.locator('.product-row')).to_have_count(32)
    page.get_by_role('searchbox', name='Найти товар').fill('такого товара нет 999')
    expect(page.locator('.no-results')).to_be_visible()
    page.get_by_role('button', name='Сбросить', exact=True).click()
    # Click and dropdown filter are synchronized.
    page.locator('.category-row').filter(has_text='Готовая еда').click()
    expect(page.locator('.filters select').nth(2)).to_have_value('Готовая еда')
    assert all('Готовая еда' in s for s in page.locator('.product-row').all_text_contents())
    chosen = [r for r in last_month if r['category'] == 'Готовая еда']
    assert numeric(page.locator('.metric-value').nth(1).inner_text()) == sum(float(r['amount']) for r in chosen)
    page.locator('.filters select').nth(0).select_option('all')
    # Monthly KPI window remains 24 months regardless of product period.
    assert page.locator('.spark svg > g').count() == 72
    page.locator('.filters select').nth(1).select_option('отменен')
    assert not errors, errors
    page.get_by_role('button', name='Сбросить', exact=True).click()
    # Invalid uploads report the error and preserve the existing dataset.
    page.locator('input[type=file]').set_input_files({'name':'invalid.csv','mimeType':'text/csv','buffer':b'wrong,column\n1,2'})
    expect(page.get_by_role('alert')).to_contain_text('Нет колонок')
    expect(page.locator('.metric-value').first).to_have_text('5')
    # Full CSV import uses the same computations without publishing the source file.
    page.locator('input[type=file]').set_input_files(str(ROOT.parent / 'Неделя 1_Визуализация_Датасет_Вариант C.csv'))
    expect(page.get_by_role('alert')).to_have_count(0)
    expect(page.locator('.metric-value').first).to_have_text('5')
    page.reload(wait_until='networkidle')
    page.mouse.move(0,0)
    page.screenshot(path=str(ROOT.parent / 'Неделя 4. Руслан Чибиров.png'), full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(200)
    assert not page.evaluate('document.documentElement.scrollWidth > innerWidth')
    assert page.locator('.product-row').count() == 12
    page.screenshot(path=str(ROOT / 'tests/mobile-preview.png'), full_page=True)
    page.locator('.product-row').nth(1).click()
    expect(page.get_by_role('dialog')).to_be_visible()
    page.keyboard.press('Tab')
    page.keyboard.press('Tab')
    assert page.evaluate('document.activeElement.closest("[role=dialog]") !== null')
    page.get_by_role('button', name='Закрыть', exact=True).click()
    assert not errors, errors
    assert not bad_responses, bad_responses
    touch_context = browser.new_context(viewport={'width':390,'height':844}, is_mobile=True, has_touch=True)
    touch_page = touch_context.new_page()
    touch_page.on('pageerror', lambda err: errors.append(str(err)))
    touch_page.goto(args.base_url, wait_until='networkidle')
    touch_page.locator('.product-row').nth(1).tap()
    expect(touch_page.get_by_role('dialog')).to_be_visible()
    assert touch_page.locator('.price-values span').count() > 0
    touch_page.get_by_role('button', name='Закрыть', exact=True).tap()
    expect(touch_page.get_by_role('dialog')).to_have_count(0)
    assert not touch_page.evaluate('document.documentElement.scrollWidth>innerWidth')
    assert not errors, errors
    touch_context.close()
    browser.close()
    report = {'browser':'Edge, clean context','url':args.base_url,'latest_month':latest,'latest_orders':expected[0],'latest_spend':expected[1],'latest_discount':expected[2],'checks':'KPI, 72 monthly points, filters, sort, search, pagination, images, hover, price modal, keyboard, upload, mobile, touch, no JS/network errors'}
    (ROOT / 'tests/qa-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))
