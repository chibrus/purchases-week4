import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {normalizeRows, summarize, monthly, monthRange, products, categories} from '../model.mjs';
const row = (id, date, item, qty, price, discounted, category='Тест') => ({order_id:id,order_date:date,item_name:item,category,quantity:qty,price,price_discounted:discounted,discount:price-discounted,amount:qty*discounted,status:'доставлен'});
test('Orders are distinct, line amounts are additive, discount is a line mean',()=>{
  const rows=normalizeRows([row('1','2026-01-02','A',2,100,90),row('1','2026-01-02','B',1,50,30),row('2','2026-03-01','A',1,150,120)]);
  assert.deepEqual(summarize(rows),{orders:2,spend:330,units:4,discount:20,lines:3});
  const m=monthly(rows,['2026-01','2026-02','2026-03']);assert.equal(m[0].orders,1);assert.equal(m[1].spend,0);assert.equal(m[1].discount,null);
  const a=products(rows,['2026-01','2026-02','2026-03']).find(p=>p.name==='A');assert.equal(a.unitPrice,100);assert.deepEqual(a.history.map(p=>p.price),[90,null,120]);
});
test('24 months include the last month and cross year boundaries',()=>{
  const months=monthRange('2026-08');assert.equal(months.length,24);assert.equal(months[0],'2024-09');assert.equal(months.at(-1),'2026-08');
});
test('An order across categories is counted once in the total',()=>{
  const rows=normalizeRows([row('1','2026-01-02','A',1,100,90,'A'),row('1','2026-01-02','B',1,100,90,'B')]);
  assert.equal(summarize(rows).orders,1);assert.equal(categories(rows).reduce((s,c)=>s+c.orders,0),2);
});
test('Malformed data cannot silently change the result',()=>{
  assert.throws(()=>normalizeRows([row('1','2026-02-31','A',1,1,1)]),/дата/);
  assert.throws(()=>normalizeRows([{...row('1','2026-01-02','A',1,1,1),amount:null}]),/amount/);
  assert.throws(()=>normalizeRows([row('1','2026-01-02','A',0,1,1)]),/количество/);
  assert.throws(()=>normalizeRows([{...row('1','2026-01-02','A',1,1,1),amount:50}]),/не согласованы/);
  assert.throws(()=>normalizeRows([row('1','2026-01-02','A',1,1,1),row('1','2026-01-03','B',1,1,1)]),/разные/);
});
test('Production dataset passes checks and 24 month totals reconcile by month and category',()=>{
  const rows=normalizeRows(JSON.parse(readFileSync(new URL('../data/orders.json',import.meta.url),'utf8')).rows);
  assert.equal(rows.length,2079);assert.equal(summarize(rows).orders,480);
  const months=monthRange('2026-08'), filtered=rows.filter(r=>r.status==='доставлен'&&months.includes(r.month));
  const total=summarize(filtered), m=monthly(filtered,months), c=categories(filtered);
  assert.ok(Math.abs(total.spend-m.reduce((s,r)=>s+r.spend,0))<.001);
  assert.ok(Math.abs(total.spend-c.reduce((s,r)=>s+r.spend,0))<.001);
  assert.equal(total.units,c.reduce((s,r)=>s+r.units,0));
  console.log('Delivered, last 24 months:',JSON.stringify(total));
});
