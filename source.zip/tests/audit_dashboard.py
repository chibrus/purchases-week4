"""Independent CSV reconciliation and end-to-end dashboard audit."""
import argparse
import csv
import io
import json
import re
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--url', default='https://chibrus.github.io/purchases-week4/')
args = parser.parse_args()
with (ROOT.parent / 'Неделя 1_Визуализация_Датасет_Вариант C.csv').open(encoding='utf-8-sig', newline='') as stream:
    source = list(csv.DictReader(stream))
for row in source:
    for field in ['price', 'price_discounted', 'discount', 'quantity', 'amount']:
        row[field] = Decimal(row[field])
last_date = max(r['order_date'] for r in source)
last_serial = int(last_date[:4]) * 12 + int(last_date[5:7]) - 1
def serial(row):
    return int(row['order_date'][:4]) * 12 + int(row['order_date'][5:7]) - 1
def summary(rows):
    return {'orders': len({r['order_id'] for r in rows}), 'spend': sum((r['amount'] for r in rows), Decimal(0)),
            'units': sum((r['quantity'] for r in rows), Decimal(0)),
            'discount': sum((r['discount'] for r in rows), Decimal(0)) / len(rows) if rows else None}
def close(actual, expected, label):
    if expected is None:
        assert actual is None, (label, actual, expected)
    else:
        assert actual is not None and abs(Decimal(str(actual)) - Decimal(expected)) < Decimal('.0000001'), (label, actual, str(expected))
def numeric(text):
    return Decimal(re.sub(r'[^0-9,.-]', '', text).replace(',', '.'))
def grouped(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[(r['category'], r['item_name'])].append(r)
    return groups
def validate_product(actual, expected):
    for field, value in summary(expected).items():
        close(actual[field], value, (actual['name'], field))
    close(actual['unitPrice'], summary(expected)['spend'] / summary(expected)['units'], 'unitPrice')
    for point in actual['history']:
        month_rows = [r for r in expected if r['order_date'].startswith(point['month'])]
        close(point['price'], summary(month_rows)['spend'] / summary(month_rows)['units'] if month_rows else None, 'monthly price')

report = {'url': args.url, 'source_rows': len(source), 'filter_cases': 0, 'sort_cases': 0, 'monthly_values': 0, 'product_months': 0, 'viewports': [], 'findings': []}
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, channel='msedge')
    context = browser.new_context(viewport={'width':1536, 'height':1100})
    page = context.new_page()
    errors, requests = [], []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('response', lambda r: requests.append((r.status, r.url)) if r.status >= 400 else None)
    page.goto(args.url, wait_until='networkidle')
    assert page.title() == 'Мои покупки | Аналитика заказов'
    expect(page.locator('.product-row')).to_have_count(12)
    selects = page.locator('.filters select')
    def select(index, value):
        selects.nth(index).select_option(value)
        page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>resolve()))')
    all_categories = sorted({r['category'] for r in source})
    for status in ['доставлен', 'отменен', 'all']:
        select(1,status)
        base = [r for r in source if status == 'all' or r['status'] == status]
        for period in ['24', '12', 'all']:
            select(0,period)
            period_rows = [r for r in base if period == 'all' or serial(r) >= last_serial-int(period)+1]
            expected_categories = {c:summary([r for r in period_rows if r['category']==c]) for c in {r['category'] for r in period_rows}}
            totals = page.locator('.category-totals strong').all_text_contents()
            total = summary(period_rows)
            assert [numeric(v) for v in totals] == [total['spend'], Decimal(total['orders']), total['units']], (status, period, totals, total)
            observed_categories = page.locator('.category-row').evaluate_all('''els=>els.map(el=>({
                name:[...el.querySelector('.category-name').childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').trim(),
                spend:el.querySelector('.category-numbers strong').textContent,
                detail:el.querySelector('.category-numbers>span').textContent,
                percent:el.querySelector('.category-name>span:last-child').textContent}))''')
            assert len(observed_categories) == len(expected_categories)
            for c in observed_categories:
                expected = expected_categories[c['name']]
                assert numeric(c['spend']) == expected['spend']
                counts = re.findall(r'[\d\s\xa0]+(?= зак| шт)', c['detail'])
                assert [numeric(v) for v in counts] == [Decimal(expected['orders']),expected['units']]
                expected_percent = expected['spend']/total['spend']*100 if total['spend'] else Decimal(0)
                assert abs(numeric(c['percent'])-expected_percent) <= Decimal('.051')
            for category in ['all'] + all_categories:
                select(2,category)
                chosen = [r for r in base if category == 'all' or r['category'] == category]
                filtered = [r for r in period_rows if category == 'all' or r['category'] == category]
                groups = grouped(filtered)
                trends = page.locator('.spark').evaluate_all('els=>els.map(el=>[...el.querySelectorAll("svg>g")].map(g=>g.__data__))')
                for metric_index, field in enumerate(['orders','spend','discount']):
                    assert len(trends[metric_index]) == 24
                    for month in trends[metric_index]:
                        expected = summary([r for r in chosen if r['order_date'].startswith(month['month'])])[field]
                        close(month[field], expected, (status,period,category,month['month'],field))
                        report['monthly_values'] += 1
                current = summary([r for r in chosen if r['order_date'].startswith(last_date[:7])])
                displayed = page.locator('.metric-value').all_text_contents()
                assert numeric(displayed[0]) == current['orders']
                assert numeric(displayed[1]) == current['spend']
                if current['discount'] is None:
                    assert displayed[2] == 'Нет данных'
                else:
                    assert abs(numeric(displayed[2])-current['discount']) <= Decimal('.051')
                for field, button in [('spend','По тратам'),('units','По количеству')]:
                    page.get_by_role('button',name=button,exact=True).click()
                    visible = page.locator('.product-row').evaluate_all('els=>els.map(el=>el.__data__)')
                    assert len(visible) == min(12,len(groups)), (status,period,category)
                    expected_values = sorted((summary(rs)[field] for rs in groups.values()),reverse=True)[:12]
                    assert [Decimal(str(d[field])) for d in visible] == expected_values
                    for product in visible:
                        validate_product(product, groups[(product['category'],product['name'])])
                        report['product_months'] += len(product['history'])
                    if not groups:
                        expect(page.locator('.no-results')).to_be_visible()
                    geometry = page.locator('.product-row').evaluate_all('''els=>els.map(el=>[...el.querySelectorAll('rect[y="32"]')].map(r=>Number(r.getAttribute('width'))))''')
                    for product, widths in zip(visible,geometry):
                        assert len(widths)==4
                        for offset, axis in [(0,'units'),(2,'spend')]:
                            expected_width = widths[offset]*product[axis]/max((v[axis] for v in visible),default=1) if max((v[axis] for v in visible),default=0) else 0
                            assert abs(widths[offset+1]-expected_width)<.000001
                    report['sort_cases'] += 1
                report['filter_cases'] += 1
        print('Reconciled status',status.encode('unicode_escape').decode(),flush=True)
    # Reach and validate every position, not only the first page.
    page.get_by_role('button',name='Сбросить',exact=True).click()
    select(1,'all');select(0,'all')
    while page.get_by_role('button',name='Показать еще 20',exact=True).count():
        page.get_by_role('button',name='Показать еще 20',exact=True).click()
    all_products = page.locator('.product-row').evaluate_all('els=>els.map(el=>el.__data__)')
    expected_products = grouped(source)
    assert len(all_products)==len(expected_products)==338
    for product in all_products:
        validate_product(product,expected_products[(product['category'],product['name'])])
    images = page.locator('.product-row image').evaluate_all('''async els=>Promise.all(els.map(el=>new Promise(resolve=>{
        const img=new Image();img.onload=()=>resolve(img.naturalWidth>0);img.onerror=()=>resolve(false);img.src=el.getAttribute('href');})))''')
    assert len(images)==338 and all(images)
    report['products_verified']=len(all_products);report['images_decoded']=len(images)
    # Search, keyboard, rotation and tooltip layout.
    page.get_by_role('button',name='Сбросить',exact=True).click()
    search = page.get_by_role('searchbox',name='Найти товар')
    search.fill('Миндаль жареный соленый')
    if page.locator('.product-row').count()!=1:
        report['findings'].append('search_diacritics')
    search.fill('такого товара нет');expect(page.locator('.no-results')).to_be_visible()
    search.fill('');expect(page.locator('.product-row')).to_have_count(12)
    target = page.locator('.product-row').nth(1);label=target.get_attribute('aria-label')
    target.focus();page.keyboard.press('Enter');expect(page.get_by_role('dialog')).to_be_visible()
    page.set_viewport_size({'width':1024,'height':800});page.wait_for_timeout(100)
    page.keyboard.press('Escape');expect(page.get_by_role('dialog')).to_have_count(0)
    page.wait_for_timeout(100)
    if page.evaluate('document.activeElement.getAttribute("aria-label")') != label:
        report['findings'].append('focus_after_resize')
    page.locator('.product-row').nth(1).scroll_into_view_if_needed();page.mouse.move(0,0);page.wait_for_timeout(80)
    page.locator('.product-row').nth(1).hover();expect(page.locator('.chart-tooltip')).to_be_visible()
    overflow = page.locator('.chart-tooltip').evaluate('''el=>{const r=el.getBoundingClientRect();return [...el.querySelectorAll('svg text')].filter(t=>{const b=t.getBoundingClientRect();return b.left<r.left-1||b.right>r.right+1}).length}''')
    if overflow:
        report['findings'].append('tooltip_tick_overflow')
    for width in [320,375,390,768,1024,1536]:
        page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(70)
        assert not page.evaluate('document.documentElement.scrollWidth>innerWidth'), width
        for category in all_categories:
            select(2,category)
            collisions = page.locator('.product-row').evaluate_all('''els=>els.some(el=>{
                const boundary=Number(el.querySelector('rect[y="32"]').getAttribute('x'));
                return [...el.querySelectorAll('text[x="50"]')].some(t=>{const b=t.getBBox();return b.x+b.width>boundary-3;});})''')
            if collisions:
                report['findings'].append('product_label_collision_'+str(width)+'_'+category)
        report['viewports'].append(width)
        select(2,'all')
    # Valid formats, fractional units, gaps and invalid-file recovery.
    fixture = [dict(order_id='test',order_date='2026-08-01',status='доставлен',item_name='Тест',category='Тест',price=20,price_discounted=15,discount=5,quantity=1.5,amount=22.5)]
    for name, body in [('test.json', json.dumps({'rows':fixture})), ('array.json',json.dumps(fixture))]:
        page.locator('input[type=file]').set_input_files({'name':name,'mimeType':'application/json','buffer':body.encode('utf-8')})
        expect(page.get_by_role('alert')).to_have_count(0)
        close(page.locator('.product-row').evaluate('el=>el.__data__.units'),Decimal('1.5'),'fractional quantity')
        select(0,'all')
        page.locator('.product-row').click();expect(page.get_by_role('dialog')).to_be_visible()
        if page.locator('.price-chart svg>g:nth-of-type(2) .tick').count()!=1:
            report['findings'].append('duplicate_single_month_ticks')
        page.get_by_role('button',name='Закрыть',exact=True).click()
    for delimiter in [',',';']:
        buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=list(fixture[0]),delimiter=delimiter);writer.writeheader();writer.writerows(fixture)
        page.locator('input[type=file]').set_input_files({'name':'test.csv','mimeType':'text/csv','buffer':('\ufeff'+buffer.getvalue()).encode('utf-8')})
        expect(page.get_by_role('alert')).to_have_count(0)
    invalid=[[],[dict(fixture[0],quantity=0)],[dict(fixture[0],order_date='2026-02-30')],[dict(fixture[0],amount=None)]]
    for data in invalid:
        page.locator('input[type=file]').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':json.dumps(data).encode()})
        expect(page.get_by_role('alert')).to_be_visible()
        expect(page.locator('.metric-value').first).to_have_text('1')
    assert not errors,errors
    assert not requests,requests
    browser.close()
report['findings']=sorted(set(report['findings']))
(ROOT/'tests/full-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=True),flush=True)
if report['findings']:
    raise SystemExit(2)
