import hashlib
import io
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import prepare_data


class ImageMappingTests(unittest.TestCase):
    def test_brand_alias_preserves_flavor(self):
        self.assertEqual(prepare_data.course_brand_alias('Лимонад Из Груши с соком груши и яблока'),
                         'лимонад из лавки с соком груши и яблока')
        self.assertEqual(prepare_data.course_brand_alias('Груша Конференция'), 'груша конференция')
        self.assertEqual(prepare_data.course_brand_alias('Eggsellent x Груша'), 'eggsellent x лавка')

    def test_unflagged_utf8_and_macos_decomposition(self):
        original = 'items/Филе охлажд\u0435\u0308нное.jpg'
        info = zipfile.ZipInfo(original.encode('utf-8').decode('cp437'))
        self.assertEqual(prepare_data.zip_name(info), 'items/Филе охлажд\u0451нное.jpg')

    def test_ambiguous_product_does_not_write_images(self):
        text = 'Код;Название позиции;Категория;Файл\n1;Вода;Вода;1.jpg\n2;Вода;Вода;2.jpg\n'
        with tempfile.TemporaryDirectory() as temp, patch.object(prepare_data, 'ROOT', Path(temp)):
            with self.assertRaisesRegex(ValueError, 'Ambiguous'):
                prepare_data.map_images(text.encode('utf-8'), lambda name: b'', [], False)
            self.assertEqual(list(Path(temp).iterdir()), [])

    def test_complete_project_coverage_and_image_integrity(self):
        root = Path(__file__).resolve().parents[1]
        manifest = json.loads((root / 'data/images.json').read_text('utf-8'))
        audit = json.loads((root / 'data/image-mapping.json').read_text('utf-8'))
        rows = json.loads((root / 'data/orders.json').read_text('utf-8'))['rows']
        self.assertEqual(len(audit), 338)
        self.assertEqual(len(manifest), 338)
        self.assertEqual({(r['category'], r['item_name']) for r in rows},
                         {(r['category'], r['item_name']) for r in audit})
        self.assertEqual(sum(r['match'] == 'exact' for r in audit), 266)
        self.assertEqual(sum(r['match'] == 'course_brand_alias' for r in audit), 72)
        for record in audit:
            with self.subTest(product=record['item_name']):
                self.assertEqual(manifest[prepare_data.key(record['item_name'])], record['image'])
                content = (root / record['image']).read_bytes()
                self.assertEqual(hashlib.sha256(content).hexdigest(), record['sha256'])
                with prepare_data.Image.open(io.BytesIO(content)) as image:
                    self.assertGreater(min(image.size), 0)
                    image.verify()
                if record['match'] == 'exact':
                    self.assertEqual(prepare_data.normalize(record['item_name']), prepare_data.normalize(record['mapped_name']))
                else:
                    self.assertEqual(prepare_data.course_brand_alias(record['item_name']), prepare_data.normalize(record['mapped_name']))
                self.assertEqual(prepare_data.course_brand_alias(record['category']), prepare_data.normalize(record['mapped_category']))


if __name__ == '__main__':
    unittest.main()
